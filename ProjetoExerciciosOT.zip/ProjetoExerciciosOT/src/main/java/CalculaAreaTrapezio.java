

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class CalculaAreaTrapezio
 */
public class CalculaAreaTrapezio extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculaAreaTrapezio() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Double basemenor = Double.parseDouble(request.getParameter("basemenor"));
		Double basemaior = Double.parseDouble(request.getParameter("basemaior"));
		Double altura = Double.parseDouble(request.getParameter("altura"));
		
		Double area = ((basemaior + basemenor)*altura) /2;
		
		PrintWriter saida= response.getWriter();
		
		saida.println("<html lang=\"pt-br\">"
				+ "<meta charset=\"UTF-8\">"
				+ "<head><title>Área do Trapezio</title></head>"
				+ "<body><h1>A áera do trapezio é:" + area +  "</h1></body>");
	}

}
